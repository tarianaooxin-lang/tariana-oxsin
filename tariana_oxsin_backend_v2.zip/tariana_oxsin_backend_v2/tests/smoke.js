const assert=require('assert');const {spawn}=require('child_process');const http=require('http');
const base='http://127.0.0.1:18080';
function req(path,opts={}){return new Promise((resolve,reject)=>{const u=new URL(base+path);const r=http.request({hostname:u.hostname,port:u.port,path:u.pathname+u.search,method:opts.method||'GET',headers:{'Content-Type':'application/json',...(opts.token?{Authorization:'Bearer '+opts.token}:{})}},res=>{let b='';res.on('data',c=>b+=c);res.on('end',()=>{let d;try{d=JSON.parse(b)}catch{};resolve({status:res.statusCode,data:d})})});r.on('error',reject);if(opts.body)r.write(JSON.stringify(opts.body));r.end()})}
(async()=>{const p=spawn(process.execPath,['server.js'],{env:{...process.env,PORT:'18080',JWT_SECRET:'test-secret'}});await new Promise(r=>setTimeout(r,1800));try{
 let x=await req('/health');assert.equal(x.status,200);assert.equal(x.data.ok,true);
 x=await req('/api/bootstrap');assert.equal(x.status,200);assert.equal(x.data.catalog.length,437);assert(x.data.groups.includes('آملون'));
 const suffix=Date.now();x=await req('/api/auth/register',{method:'POST',body:{name:'تست '+suffix,nationalId:'1234567890',nationalIdType:'national',phone:'0912'+String(suffix).slice(-7),password:'test1234',requestedTier:'retail'}});assert.equal(x.status,200);
 x=await req('/api/admin/login',{method:'POST',body:{username:'admin',password:'1234'}});assert.equal(x.status,200);const at=x.data.token;
 x=await req('/api/admin/users',{token:at});assert.equal(x.status,200);const cu=x.data.users.find(u=>u.role==='customer'&&u.name==='تست '+suffix);assert(cu);
 x=await req('/api/admin/users/'+cu.id,{method:'PUT',token:at,body:{status:'approved'}});assert.equal(x.status,200);
 x=await req('/api/auth/login',{method:'POST',body:{name:'تست '+suffix,phone:'0912'+String(suffix).slice(-7),password:'test1234'}});assert.equal(x.status,200);const ct=x.data.token;
 x=await req('/api/me',{token:ct});assert.equal(x.status,200);
 x=await req('/api/admin/catalog',{token:at});const prod=x.data.catalog[0];const old=prod.price;
 x=await req('/api/admin/products/'+prod.id,{method:'PUT',token:at,body:{price:'987654321',tiers:prod.tiers||{}}});assert.equal(x.status,200);
 x=await req('/api/admin/catalog',{token:at});assert.equal(x.data.catalog.find(p=>p.id===prod.id).price,'987654321');
 x=await req('/api/orders',{method:'POST',token:ct,body:{items:[{productId:prod.id,quantity:2}]}});assert.equal(x.status,200);assert(x.data.order.orderNumber);
 x=await req('/api/admin/password',{method:'PUT',token:at,body:{oldPassword:'1234',newPassword:'4321'}});assert.equal(x.status,200);
 x=await req('/api/admin/login',{method:'POST',body:{username:'admin',password:'4321'}});assert.equal(x.status,200);
 x=await req('/api/admin/password',{method:'PUT',token:x.data.token,body:{oldPassword:'4321',newPassword:'1234'}});assert.equal(x.status,200);
 console.log('BACKEND SMOKE TESTS: ALL PASSED');
}catch(e){console.error('TEST FAILED',e);process.exitCode=1}finally{p.kill('SIGTERM')}})();
